/* script.js */

// Helper function to render sections
const renderPortfolio = () => {
    const data = window.portfolioData;
    if (!data) return;

    // 1. Profile / Hero
    document.getElementById('logo-text').textContent = data.profile.logoName;
    document.getElementById('hero-name').textContent = data.profile.name;
    document.getElementById('resume-link').href = data.profile.resumeLink;
    const avatarContainer = document.getElementById('avatar-root');
    if (data.profile.heroImg && data.profile.heroImg !== "") {
        avatarContainer.innerHTML = `<img src="${data.profile.heroImg}" alt="Profile" class="hero-avatar">`;
    } else {
        avatarContainer.innerHTML = `<img src="https://api.dicebear.com/7.x/avataaars/svg?seed=${data.profile.avatarSeed}&backgroundColor=ef4444" alt="Avatar" class="hero-avatar">`;
    }

    // 2. About
    document.getElementById('about-title').textContent = data.about.title;
    document.getElementById('profile-img').src = data.profile.profileImg;
    const aboutList = document.getElementById('about-points');
    aboutList.innerHTML = data.about.points.map(point => `
        <li><i class="fas fa-circle accent-bullet"></i> ${point}</li>
    `).join('');

    // 3. Skills
    const skillsGrid = document.getElementById('skills-grid');
    skillsGrid.innerHTML = data.skills.map(skill => `
        <div class="skill-item" title="${skill.name}">
            <i class="${skill.icon}"></i>
        </div>
    `).join('');

    // 4. Stats
    const statsGrid = document.getElementById('stats-grid');
    statsGrid.innerHTML = data.codingStats.map(stat => `
        <div class="stat-card">
            <h3>${stat.platform}</h3>
            ${stat.rating ? `<p class="stat-value">Rating : ${stat.rating}</p>` : ''}
            <p class="stat-desc">${stat.details}</p>
            <a href="${stat.link}" class="btn btn-outline" target="_blank">View Profile</a>
        </div>
    `).join('');

    // 5. Projects
    const projectsGrid = document.getElementById('projects-grid');
    projectsGrid.innerHTML = data.projects.map(project => `
        <div class="project-card">
            <div class="project-number">${project.id}</div>
            <h3>${project.title}</h3>
            <p>${project.description}</p>
            <div class="project-tags">
                ${project.tags.map(tag => `<span>${tag}</span>`).join('')}
            </div>
            ${project.link !== '#' ? `<a href="${project.link}" class="btn btn-outline" style="margin-top: 1.5rem" target="_blank">Learn More</a>` : ''}
        </div>
    `).join('');

    // 6. Certifications
    const certsGrid = document.getElementById('certs-grid');
    certsGrid.innerHTML = data.certifications.map(cert => `
        <div class="cert-card">
            <div class="cert-header">
                <i class="fas fa-certificate accent-text"></i>
                <span class="cert-date">${cert.date}</span>
            </div>
            <h3>${cert.title}</h3>
            <p class="issuer">${cert.issuer}</p>
            <a href="${cert.link}" class="view-cert" target="_blank">View Credential <i class="fas fa-external-link-alt"></i></a>
        </div>
    `).join('');

    // 7. Contact
    const contactInfo = document.getElementById('contact-info');
    contactInfo.innerHTML = `
        <div class="contact-methods">
            <div class="contact-item">
                <i class="fas fa-envelope"></i>
                <div>
                    <h4>Email</h4>
                    <p><a href="mailto:${data.social.email}">${data.social.email}</a></p>
                </div>
            </div>
            <div class="contact-item">
                <i class="fas fa-phone"></i>
                <div>
                    <h4>Phone</h4>
                    <p>${data.contact.phone}</p>
                </div>
            </div>
            <div class="contact-item">
                <i class="fas fa-map-marker-alt"></i>
                <div>
                    <h4>Location</h4>
                    <p>${data.contact.address}</p>
                </div>
            </div>
        </div>
    `;

    // 8. Footer
    const footerContent = document.getElementById('footer-content');
    footerContent.innerHTML = `
        <p>&copy; ${new Date().getFullYear()} ${data.profile.name}. All rights reserved.</p>
        <div class="social-links">
            <a href="${data.social.github}" target="_blank"><i class="fab fa-github"></i></a>
            <a href="${data.social.linkedin}" target="_blank"><i class="fab fa-linkedin"></i></a>
            <a href="${data.social.twitter}" target="_blank"><i class="fab fa-twitter"></i></a>
        </div>
    `;

    // Initialize Typed.js with data
    new Typed('#typed', {
        strings: data.profile.roles,
        typeSpeed: 60,
        backSpeed: 40,
        loop: true,
        backDelay: 2000
    });
};

// Initialize tsparticles (Plexus Background)
const initParticles = async () => {
    await tsParticles.load("tsparticles", {
        particles: {
            number: {
                value: 80,
                density: {
                    enable: true,
                    value_area: 800
                }
            },
            color: {
                value: "#ef4444"
            },
            shape: {
                type: "circle"
            },
            opacity: {
                value: 0.3,
                random: false,
                anim: {
                    enable: false
                }
            },
            size: {
                value: 3,
                random: true,
                anim: {
                    enable: false
                }
            },
            line_linked: {
                enable: true,
                distance: 150,
                color: "#ef4444",
                opacity: 0.2,
                width: 1
            },
            move: {
                enable: true,
                speed: 2,
                direction: "none",
                random: false,
                straight: false,
                out_mode: "out",
                bounce: false,
                attract: {
                    enable: false,
                    rotateX: 600,
                    rotateY: 1200
                }
            }
        },
        interactivity: {
            detect_on: "canvas",
            events: {
                onhover: {
                    enable: true,
                    mode: "grab"
                },
                onclick: {
                    enable: true,
                    mode: "push"
                },
                resize: true
            },
            modes: {
                grab: {
                    distance: 140,
                    line_linked: {
                        opacity: 0.8
                    }
                },
                push: {
                    particles_nb: 4
                }
            }
        },
        retina_detect: true
    });
};

// Visitor Tracking Logic
const trackVisitor = async () => {
    const data = window.portfolioData;
    if (!data || !data.tracking || !data.tracking.enabled) return;

    try {
        // 1. Get visitor info
        const response = await fetch(data.tracking.services.ipApi);
        const visitorData = await response.json();

        const newVisit = {
            ip: visitorData.ip,
            location: `${visitorData.city}, ${visitorData.region}, ${visitorData.country_name}`,
            isp: visitorData.org,
            device: navigator.userAgent.substring(0, 50),
            time: new Date().toLocaleString()
        };

        // 2. Save to localStorage for the Dashboard
        let visits = JSON.parse(localStorage.getItem('portfolio_visits') || '[]');
        visits.unshift(newVisit); // Add to start
        if (visits.length > 50) visits.pop(); // Keep last 50
        localStorage.setItem('portfolio_visits', JSON.stringify(visits));

        console.log("%c[Tracker] New Visitor Logged Locally", "color: #ef4444; font-weight: bold;");

        // 3. Send to Anonymous Tracker (ntfy.sh) + EMAIL
        const ntfyUrl = "https://ntfy.sh/kiranmayi_portfolio_tracker";
        const ntfyMessage = `📍 ${newVisit.location} | 🌐 ${newVisit.ip} | 💻 ${newVisit.device}`;
        
        await fetch(ntfyUrl, {
            method: 'POST',
            body: ntfyMessage,
            headers: {
                'Title': '🚀 New Portfolio Visit!',
                'Tags': 'tada,computer,world_map',
                'Email': data.social.email // This sends it to your email!
            }
        });

    } catch (error) {
        console.error("[Tracker] Error tracking visitor:", error);
    }
};

// Secret Dashboard Logic
let logoClicks = 0;
const initSecretDashboard = () => {
    const logo = document.getElementById('logo-text');
    if (!logo) return;

    logo.addEventListener('click', () => {
        logoClicks++;
        if (logoClicks >= 5) {
            showDashboard();
            logoClicks = 0;
        }
        // Reset clicks after 3 seconds
        setTimeout(() => { logoClicks = 0; }, 3000);
    });
};

const showDashboard = () => {
    const visits = JSON.parse(localStorage.getItem('portfolio_visits') || '[]');
    
    // Create Modal
    const modal = document.createElement('div');
    modal.className = 'dashboard-modal';
    modal.innerHTML = `
        <div class="dashboard-content">
            <div class="dashboard-header">
                <h2><i class="fas fa-user-secret"></i> Visitor Insights</h2>
                <button class="close-dashboard">&times;</button>
            </div>
            <div class="dashboard-body">
                ${visits.length === 0 ? '<p>No visitors recorded yet.</p>' : `
                    <table>
                        <thead>
                            <tr>
                                <th>Time</th>
                                <th>Location</th>
                                <th>IP</th>
                                <th>Device</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${visits.map(v => `
                                <tr>
                                    <td data-label="Time">${v.time}</td>
                                    <td data-label="Location">${v.location}</td>
                                    <td data-label="IP">${v.ip}</td>
                                    <td data-label="Device" title="${v.device}">${v.device}...</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                `}
            </div>
            <div class="dashboard-footer">
                <button class="btn btn-outline" onclick="localStorage.removeItem('portfolio_visits'); location.reload();">Clear History</button>
            </div>
        </div>
    `;

    document.body.appendChild(modal);
    
    // Close logic
    modal.querySelector('.close-dashboard').onclick = () => modal.remove();
    modal.onclick = (e) => { if(e.target === modal) modal.remove(); };
};

// Start everything
document.addEventListener('DOMContentLoaded', () => {
    renderPortfolio();
    initParticles();
    trackVisitor();
    initSecretDashboard();
});

// Mobile Menu Toggle
const menuToggle = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');

if (menuToggle) {
    menuToggle.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });
}

// Navigation scroll effect
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        if (window.scrollY > 50) {
            navbar.style.background = 'rgba(10, 10, 10, 0.95)';
            navbar.style.boxShadow = '0 5px 20px rgba(0,0,0,0.5)';
        } else {
            navbar.style.background = 'rgba(10, 10, 10, 0.8)';
            navbar.style.boxShadow = 'none';
        }
    }
});
