@echo off
echo Starting your Portfolio Server...
start "" http://localhost:8000
python -m http.server 8000
