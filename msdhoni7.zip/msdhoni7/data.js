/* data.js */

const portfolioData = {
    profile: {
        name: "Reddy Kiranmayi",
        logoName: "Kiranmayi",
        avatarSeed: "Kiranmayi", // Used for the generated avatar
        roles: [
            "Full Stack Developer",
            "AI Enthusiast",
            "UI/UX Designer",
            "Competitive Coder"
        ],
        resumeLink: "resume.pdf",
        profileImg: "./profile.jpg",
        heroImg: "./profile.jpg"
    },
    about: {
        title: "About Me",
        points: [
            "Hi, I'm Kiranmayi, a B.Tech Computer Science Engineering student",
            "College : ACE Engineering College",
            "Aspiring Computer Science enthusiast with a passion for innovation, skilled in coding, web development, and AI-driven solutions.",
            "Driven to create impactful technologies, with hands-on experience in smart projects and competitive coding excellence."
        ]
    },
    skills: [
        { name: "Java", icon: "fab fa-java" },
        { name: "HTML5", icon: "fab fa-html5" },
        { name: "CSS3", icon: "fab fa-css3-alt" },
        { name: "JavaScript", icon: "fab fa-js" },
        { name: "React", icon: "fab fa-react" },
        { name: "Node.js", icon: "fab fa-node-js" },
        { name: "Python", icon: "fab fa-python" },
        { name: "Database", icon: "fas fa-database" },
        { name: "Git", icon: "fab fa-git-alt" },
        { name: "Machine Learning", icon: "fas fa-brain" }
    ],
    codingStats: [
        {
            platform: "LeetCode",
            rating: "1238",
            details: "Solved 200+ problems",
            link: "#"
        },
        {
            platform: "Codechef",
            rating: "1418",
            details: "2-star coder",
            link: "#"
        },
        {
            platform: "Geeks For Geeks",
            rating: "2nd Rank",
            details: "Solved 300+ problems",
            link: "#"
        }
    ],
    projects: [
        {
            id: "01",
            title: "Crime Hotspot Detection",
            description: "A web application to visualize and analyze crime hotspots using crowdsourced data.",
            tags: ["Flask", "SQLite", "Leaflet"],
            link: "#"
        },
        {
            id: "02",
            title: "AI Resume Parser",
            description: "Extracting insights from resumes using NLP and machine learning models.",
            tags: ["Python", "NLP", "FastAPI"],
            link: "#"
        },
        {
            id: "03",
            title: "Smart Portfolio",
            description: "A premium, dynamic portfolio website with glassmorphism and plexus effects.",
            tags: ["HTML", "CSS", "JavaScript"],
            link: "#"
        }
    ],
    social: {
        github: "#",
        linkedin: "#",
        twitter: "#",
        email: "kiranmayi@example.com"
    },
    certifications: [
        {
            title: "Java Full Stack Development",
            issuer: "Oracle / Coursera",
            date: "2024",
            link: "#"
        },
        {
            title: "Google Data Analytics",
            issuer: "Google",
            date: "2023",
            link: "#"
        }
    ],
    contact: {
        phone: "+91 1234567890",
        address: "Hyderabad, India"
    },
    tracking: {
        enabled: true,
        services: {
            ipApi: "https://ipapi.co/json/"
        }
    }
};

// Export for logic use
window.portfolioData = portfolioData;
