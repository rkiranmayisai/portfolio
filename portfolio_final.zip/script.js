/* script.js */

// Helper function to render sections
const renderPortfolio = () => {
    const data = window.portfolioData;
    if (!data) return;

    // 1. Profile / Hero
    document.getElementById('logo-text').textContent = data.profile.logoName;
    document.getElementById('hero-name').textContent = data.profile.name;
    document.getElementById('resume-link').href = data.profile.resumeLink;
    const avatarContainer = document.getElementById('avatar-root');
    if (data.profile.heroImg && data.profile.heroImg !== "") {
        avatarContainer.innerHTML = `<img src="${data.profile.heroImg}" alt="Profile" class="hero-avatar">`;
    } else {
        avatarContainer.innerHTML = `<img src="https://api.dicebear.com/7.x/avataaars/svg?seed=${data.profile.avatarSeed}&backgroundColor=ef4444" alt="Avatar" class="hero-avatar">`;
    }

    // 2. About
    document.getElementById('about-title').textContent = data.about.title;
    document.getElementById('profile-img').src = data.profile.profileImg;
    const aboutList = document.getElementById('about-points');
    aboutList.innerHTML = data.about.points.map(point => `
        <li><i class="fas fa-circle accent-bullet"></i> ${point}</li>
    `).join('');

    // 3. Skills
    const skillsGrid = document.getElementById('skills-grid');
    skillsGrid.innerHTML = data.skills.map(skill => `
        <div class="skill-item" title="${skill.name}">
            <i class="${skill.icon}"></i>
        </div>
    `).join('');

    // 4. Stats
    const statsGrid = document.getElementById('stats-grid');
    statsGrid.innerHTML = data.codingStats.map(stat => `
        <div class="stat-card">
            <h3>${stat.platform}</h3>
            ${stat.rating ? `<p class="stat-value">Rating : ${stat.rating}</p>` : ''}
            <p class="stat-desc">${stat.details}</p>
            <a href="${stat.link}" class="btn btn-outline" target="_blank">View Profile</a>
        </div>
    `).join('');

    // 5. Projects
    const projectsGrid = document.getElementById('projects-grid');
    projectsGrid.innerHTML = data.projects.map(project => `
        <div class="project-card">
            <div class="project-number">${project.id}</div>
            <h3>${project.title}</h3>
            <p>${project.description}</p>
            <div class="project-tags">
                ${project.tags.map(tag => `<span>${tag}</span>`).join('')}
            </div>
            ${project.link !== '#' ? `<a href="${project.link}" class="btn btn-outline" style="margin-top: 1.5rem" target="_blank">Learn More</a>` : ''}
        </div>
    `).join('');

    // 6. Certifications
    const certsGrid = document.getElementById('certs-grid');
    certsGrid.innerHTML = data.certifications.map(cert => `
        <div class="cert-card">
            <div class="cert-header">
                <i class="fas fa-certificate accent-text"></i>
                <span class="cert-date">${cert.date}</span>
            </div>
            <h3>${cert.title}</h3>
            <p class="issuer">${cert.issuer}</p>
            <a href="${cert.link}" class="view-cert" target="_blank">View Credential <i class="fas fa-external-link-alt"></i></a>
        </div>
    `).join('');

    // 7. Contact
    const contactInfo = document.getElementById('contact-info');
    contactInfo.innerHTML = `
        <div class="contact-methods">
            <div class="contact-item">
                <i class="fas fa-envelope"></i>
                <div>
                    <h4>Email</h4>
                    <p><a href="mailto:${data.social.email}">${data.social.email}</a></p>
                </div>
            </div>
            <div class="contact-item">
                <i class="fas fa-phone"></i>
                <div>
                    <h4>Phone</h4>
                    <p>${data.contact.phone}</p>
                </div>
            </div>
            <div class="contact-item">
                <i class="fas fa-map-marker-alt"></i>
                <div>
                    <h4>Location</h4>
                    <p>${data.contact.address}</p>
                </div>
            </div>
        </div>
    `;

    // 8. Footer
    const footerContent = document.getElementById('footer-content');
    footerContent.innerHTML = `
        <p>&copy; ${new Date().getFullYear()} ${data.profile.name}. All rights reserved.</p>
        <div class="social-links">
            <a href="${data.social.github}" target="_blank"><i class="fab fa-github"></i></a>
            <a href="${data.social.linkedin}" target="_blank"><i class="fab fa-linkedin"></i></a>
            <a href="${data.social.twitter}" target="_blank"><i class="fab fa-twitter"></i></a>
        </div>
    `;

    // Initialize Typed.js with data
    new Typed('#typed', {
        strings: data.profile.roles,
        typeSpeed: 60,
        backSpeed: 40,
        loop: true,
        backDelay: 2000
    });
};

// Initialize tsparticles (Plexus Background)
const initParticles = async () => {
    await tsParticles.load("tsparticles", {
        particles: {
            number: {
                value: 80,
                density: {
                    enable: true,
                    value_area: 800
                }
            },
            color: {
                value: "#ef4444"
            },
            shape: {
                type: "circle"
            },
            opacity: {
                value: 0.3,
                random: false,
                anim: {
                    enable: false
                }
            },
            size: {
                value: 3,
                random: true,
                anim: {
                    enable: false
                }
            },
            line_linked: {
                enable: true,
                distance: 150,
                color: "#ef4444",
                opacity: 0.2,
                width: 1
            },
            move: {
                enable: true,
                speed: 2,
                direction: "none",
                random: false,
                straight: false,
                out_mode: "out",
                bounce: false,
                attract: {
                    enable: false,
                    rotateX: 600,
                    rotateY: 1200
                }
            }
        },
        interactivity: {
            detect_on: "canvas",
            events: {
                onhover: {
                    enable: true,
                    mode: "grab"
                },
                onclick: {
                    enable: true,
                    mode: "push"
                },
                resize: true
            },
            modes: {
                grab: {
                    distance: 140,
                    line_linked: {
                        opacity: 0.8
                    }
                },
                push: {
                    particles_nb: 4
                }
            }
        },
        retina_detect: true
    });
};

// Start everything
document.addEventListener('DOMContentLoaded', () => {
    renderPortfolio();
    initParticles();
});

// Mobile Menu Toggle
const menuToggle = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');

if (menuToggle) {
    menuToggle.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });
}

// Navigation scroll effect
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        if (window.scrollY > 50) {
            navbar.style.background = 'rgba(10, 10, 10, 0.95)';
            navbar.style.boxShadow = '0 5px 20px rgba(0,0,0,0.5)';
        } else {
            navbar.style.background = 'rgba(10, 10, 10, 0.8)';
            navbar.style.boxShadow = 'none';
        }
    }
});
